create procedure selectUser()
BEGIN
	#Routine body goes here...
select * from t_user;
END;

