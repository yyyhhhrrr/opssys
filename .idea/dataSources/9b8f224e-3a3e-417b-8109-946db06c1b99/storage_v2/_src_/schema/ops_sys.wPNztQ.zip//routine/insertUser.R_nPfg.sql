create procedure insertUser(IN name varchar(20), IN password varchar(20))
BEGIN
INSERT INTO t_user (us_username,us_password)VALUES(name,password);
END;

